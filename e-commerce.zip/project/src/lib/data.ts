import { Product, Category } from './types';

export const categories: Category[] = [
  { id: 'all', name: 'All Products', color: 'bg-gray-500' },
  { id: 'electronics', name: 'Electronics', color: 'bg-blue-500' },
  { id: 'accessories', name: 'Accessories', color: 'bg-purple-500' },
  { id: 'fashion', name: 'Fashion', color: 'bg-pink-500' },
  { id: 'sports', name: 'Sports', color: 'bg-green-500' }
];

export const products: Product[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones",
    price: 299.99,
    description: "High-quality wireless headphones with noise cancellation",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80",
    category: "Electronics",
    rating: 4.5,
    reviews: 128,
    colors: ['Black', 'White', 'Rose Gold']
  },
  {
    id: 2,
    name: "Minimalist Watch",
    price: 199.99,
    description: "Elegant minimalist watch with leather strap",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80",
    category: "Accessories",
    rating: 4.8,
    reviews: 89,
    colors: ['Brown', 'Black', 'Navy']
  },
  {
    id: 3,
    name: "Smart Fitness Tracker",
    price: 149.99,
    description: "Advanced fitness tracking with heart rate monitoring",
    image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=500&q=80",
    category: "Electronics",
    rating: 4.3,
    reviews: 256,
    colors: ['Black', 'Blue', 'Pink']
  },
  {
    id: 4,
    name: "Designer Sunglasses",
    price: 179.99,
    description: "Premium UV protection sunglasses",
    image: "https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&q=80",
    category: "Accessories",
    rating: 4.6,
    reviews: 67,
    colors: ['Black', 'Tortoise', 'Gold']
  },
  {
    id: 5,
    name: "Running Shoes",
    price: 129.99,
    description: "Lightweight and comfortable running shoes",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80",
    category: "Sports",
    rating: 4.7,
    reviews: 195,
    colors: ['Red', 'Blue', 'Black'],
    sizes: ['US 7', 'US 8', 'US 9', 'US 10', 'US 11']
  },
  {
    id: 6,
    name: "Leather Backpack",
    price: 89.99,
    description: "Stylish and durable leather backpack",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&q=80",
    category: "Fashion",
    rating: 4.4,
    reviews: 156,
    colors: ['Brown', 'Black', 'Tan']
  },
  {
    id: 7,
    name: "Smart Speaker",
    price: 199.99,
    description: "Voice-controlled smart speaker with premium sound",
    image: "https://images.unsplash.com/photo-1543512214-318c7553f230?w=500&q=80",
    category: "Electronics",
    rating: 4.2,
    reviews: 234,
    colors: ['Black', 'White', 'Gray']
  },
  {
    id: 8,
    name: "Yoga Mat",
    price: 49.99,
    description: "Premium non-slip yoga mat",
    image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=500&q=80",
    category: "Sports",
    rating: 4.8,
    reviews: 178,
    colors: ['Purple', 'Blue', 'Green']
  }
];