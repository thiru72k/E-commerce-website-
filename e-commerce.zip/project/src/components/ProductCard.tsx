import { Product } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ShoppingCart, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useState } from 'react';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product, color?: string, size?: string) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  const { toast } = useToast();
  const [selectedColor, setSelectedColor] = useState<string>();
  const [selectedSize, setSelectedSize] = useState<string>();

  const handleAddToCart = () => {
    onAddToCart(product, selectedColor, selectedSize);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`
    });
  };

  return (
    <Card className="w-full max-w-sm transition-all hover:shadow-lg bg-white dark:bg-gray-800">
      <CardHeader className="p-0">
        <div className="aspect-square overflow-hidden rounded-t-lg relative group">
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="secondary">Quick View</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{product.name}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <img src={product.image} alt={product.name} className="rounded-lg" />
                    <div>
                      <p className="text-muted-foreground mb-4">{product.description}</p>
                      <div className="flex items-center gap-2 mb-4">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(product.rating)
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-gray-300'
                            }`}
                          />
                        ))}
                        <span className="text-sm text-muted-foreground">
                          ({product.reviews} reviews)
                        </span>
                      </div>
                      {product.colors && (
                        <div className="mb-4">
                          <Label>Color</Label>
                          <RadioGroup
                            value={selectedColor}
                            onValueChange={setSelectedColor}
                            className="flex gap-2 mt-2"
                          >
                            {product.colors.map((color) => (
                              <div key={color} className="flex items-center space-x-2">
                                <RadioGroupItem value={color} id={`color-${color}`} />
                                <Label htmlFor={`color-${color}`}>{color}</Label>
                              </div>
                            ))}
                          </RadioGroup>
                        </div>
                      )}
                      {product.sizes && (
                        <div className="mb-4">
                          <Label>Size</Label>
                          <RadioGroup
                            value={selectedSize}
                            onValueChange={setSelectedSize}
                            className="flex gap-2 mt-2"
                          >
                            {product.sizes.map((size) => (
                              <div key={size} className="flex items-center space-x-2">
                                <RadioGroupItem value={size} id={`size-${size}`} />
                                <Label htmlFor={`size-${size}`}>{size}</Label>
                              </div>
                            ))}
                          </RadioGroup>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <Button onClick={handleAddToCart} className="w-full">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  Add to Cart
                </Button>
              </DialogContent>
            </Dialog>
          </div>
        </div>
        <div className="p-6">
          <CardTitle className="mb-2">{product.name}</CardTitle>
          <div className="flex items-center gap-2 mb-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 ${
                  i < Math.floor(product.rating)
                    ? 'fill-yellow-400 text-yellow-400'
                    : 'text-gray-300'
                }`}
              />
            ))}
            <span className="text-sm text-muted-foreground">
              ({product.reviews})
            </span>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{product.description}</p>
        <p className="mt-2 text-2xl font-bold text-primary">${product.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter>
        <Button onClick={handleAddToCart} className="w-full bg-primary hover:bg-primary/90">
          <ShoppingCart className="mr-2 h-4 w-4" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}